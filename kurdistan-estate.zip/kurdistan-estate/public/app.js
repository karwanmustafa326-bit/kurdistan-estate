const API = '/api';
let token = localStorage.getItem('token') || null;
let currentUser = JSON.parse(localStorage.getItem('user') || 'null');
let allListings = [];
let activeFilter = 'all';
let map, markersLayer;

const TYPE_COLORS = {
  'خانوو': ['#1f6d68', '#154e4a'], 'ئاپارتمان': ['#c1882f', '#8a5e1c'],
  'زەوی': ['#a4402f', '#6f2a1f'], 'دوکان': ['#8a6b2f', '#5c4720'],
};

function authHeaders() {
  return token ? { Authorization: 'Bearer ' + token } : {};
}

function houseIcon(type) {
  const [c1, c2] = TYPE_COLORS[type] || TYPE_COLORS['خانوو'];
  return `<svg viewBox="0 0 200 150" xmlns="http://www.w3.org/2000/svg">
    <rect width="200" height="150" fill="${c1}"/>
    <path d="M0 110 L40 80 L75 105 L115 65 L150 95 L200 60 L200 150 L0 150 Z" fill="${c2}" opacity=".6"/>
    <rect x="70" y="70" width="60" height="45" fill="#fffdf8" opacity=".92"/>
    <path d="M65 70 L100 45 L135 70 Z" fill="#fffdf8" opacity=".92"/>
    <rect x="92" y="90" width="16" height="25" fill="${c1}"/>
  </svg>`;
}

function updateUserUI() {
  const whoami = document.getElementById('whoami');
  const loginBtn = document.getElementById('loginBtn');
  const rolepick = document.getElementById('rolepick');
  if (currentUser) {
    whoami.style.display = 'flex';
    whoami.innerHTML = `<div class="avatar">${currentUser.name.charAt(0)}</div><span>${currentUser.name}</span> <button class="btn btn-ghost btn-sm" id="logoutBtn">دەرچوون</button>`;
    document.getElementById('logoutBtn').addEventListener('click', logout);
    loginBtn.style.display = 'none';
    rolepick.style.display = 'flex';
    rolepick.querySelectorAll('button').forEach(b => b.classList.toggle('active', b.dataset.role === currentUser.role));
  } else {
    whoami.style.display = 'none';
    loginBtn.style.display = 'inline-flex';
    rolepick.style.display = 'none';
  }
}

function logout() {
  token = null; currentUser = null;
  localStorage.removeItem('token'); localStorage.removeItem('user');
  updateUserUI();
}

async function fetchListings() {
  const res = await fetch(`${API}/listings`);
  const data = await res.json();
  allListings = data.listings || [];
  render();
  updateStats();
  refreshMapMarkers();
}

function updateStats() {
  document.getElementById('statCount').textContent = allListings.length;
  document.getElementById('statCities').textContent = new Set(allListings.map(l => l.city)).size;
  ['خانوو', 'ئاپارتمان', 'زەوی', 'دوکان'].forEach(t => {
    const el = document.getElementById('cnt-' + t);
    if (el) el.textContent = allListings.filter(l => l.type === t).length + ' ئەندام';
  });
}

function render() {
  const q = document.getElementById('q').value.trim();
  const city = document.getElementById('city').value;
  const type = document.getElementById('type').value;

  const filtered = allListings.filter(l => {
    if (activeFilter !== 'all' && l.type !== activeFilter) return false;
    if (type && l.type !== type) return false;
    if (city && l.city !== city) return false;
    if (q && !((l.title || '').includes(q) || (l.area || '').includes(q) || (l.city || '').includes(q))) return false;
    return true;
  });

  const grid = document.getElementById('grid');
  grid.innerHTML = filtered.map(l => {
    const mine = currentUser && l.owner_id === currentUser.id;
    return `
    <div class="card">
      <div class="thumb">${houseIcon(l.type)}<span class="badge">${l.type}</span></div>
      <div class="card-body">
        <div class="price">${l.price}</div>
        <p class="title">${l.title}</p>
        <div class="loc">${l.area}، ${l.city}</div>
        <div class="meta"><span>${l.size}</span>${l.beds ? `<span>${l.beds} ژوور</span>` : ''}</div>
        ${l.owner_name ? `<div class="card-foot-row"><span class="owner-tag">لەلایەن ${l.owner_name}</span>${mine ? `<button class="del-btn" data-id="${l.id}">سڕینەوە</button>` : ''}</div>` : ''}
      </div>
    </div>`;
  }).join('');

  document.getElementById('empty').style.display = filtered.length ? 'none' : 'block';

  grid.querySelectorAll('.del-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const res = await fetch(`${API}/listings/${btn.dataset.id}`, { method: 'DELETE', headers: authHeaders() });
      if (res.ok) fetchListings();
    });
  });
}

// ---- Map ----
function initMap() {
  map = L.map('leafletMap', { scrollWheelZoom: false }).setView([36.2, 44.2], 7);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors',
  }).addTo(map);
  markersLayer = L.layerGroup().addTo(map);
}

function refreshMapMarkers() {
  if (!markersLayer) return;
  markersLayer.clearLayers();
  const byCity = {};
  allListings.forEach(l => {
    if (l.lat == null || l.lng == null) return;
    byCity[l.city] = byCity[l.city] || { lat: l.lat, lng: l.lng, count: 0 };
    byCity[l.city].count++;
  });
  Object.entries(byCity).forEach(([city, info]) => {
    const marker = L.circleMarker([info.lat, info.lng], {
      radius: 9, color: '#1f6d68', fillColor: '#c1882f', fillOpacity: 0.9, weight: 2,
    }).addTo(markersLayer);
    marker.bindTooltip(`${city} — ${info.count} ئەندام`, { permanent: false });
    marker.on('click', () => {
      document.getElementById('city').value = city;
      render();
      document.getElementById('listings').scrollIntoView({ behavior: 'smooth' });
    });
  });
}

// ---- Filters ----
document.querySelectorAll('.chip').forEach(chip => {
  chip.addEventListener('click', () => {
    document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
    chip.classList.add('active');
    activeFilter = chip.dataset.filter;
    render();
  });
});
document.querySelectorAll('.cat-card').forEach(card => {
  card.addEventListener('click', () => {
    const cat = card.dataset.cat;
    document.querySelectorAll('.chip').forEach(c => c.classList.toggle('active', c.dataset.filter === cat));
    activeFilter = cat;
    render();
    document.getElementById('listings').scrollIntoView({ behavior: 'smooth' });
  });
});
document.getElementById('searchBtn').addEventListener('click', render);
document.getElementById('q').addEventListener('keydown', e => { if (e.key === 'Enter') render(); });
document.getElementById('city').addEventListener('change', render);
document.getElementById('type').addEventListener('change', render);

// ---- Post listing modal ----
const postBackdrop = document.getElementById('modalBackdrop');
const postForm = document.getElementById('postForm');
const postMsg = document.getElementById('postMsg');

function openPostModal() {
  postMsg.className = 'field-full form-msg';
  if (!currentUser) {
    openAuthModal('login');
    return;
  }
  postBackdrop.classList.add('open');
}
document.querySelectorAll('.js-open-post').forEach(b => b.addEventListener('click', (e) => { e.preventDefault(); openPostModal(); }));
document.getElementById('modalClose').addEventListener('click', () => postBackdrop.classList.remove('open'));
document.getElementById('postCancel').addEventListener('click', () => postBackdrop.classList.remove('open'));
postBackdrop.addEventListener('click', e => { if (e.target === postBackdrop) postBackdrop.classList.remove('open'); });

postForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const body = {
    title: document.getElementById('f-title').value.trim(),
    city: document.getElementById('f-city').value,
    area: document.getElementById('f-area').value.trim(),
    type: document.getElementById('f-type').value,
    price: document.getElementById('f-price').value.trim(),
    size: document.getElementById('f-size').value.trim(),
    beds: Number(document.getElementById('f-beds').value) || 0,
  };
  const res = await fetch(`${API}/listings`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) {
    postMsg.textContent = data.error || 'هەڵەیەک ڕوویدا';
    postMsg.className = 'field-full form-msg show err';
    return;
  }
  postForm.reset();
  postBackdrop.classList.remove('open');
  fetchListings();
});

// ---- Auth modal ----
const authBackdrop = document.getElementById('authBackdrop');
const authForm = document.getElementById('authForm');
const authMsg = document.getElementById('authMsg');
let authMode = 'login';

function openAuthModal(mode) {
  authMode = mode;
  authMsg.className = 'field-full form-msg';
  document.getElementById('nameField').style.display = mode === 'register' ? 'block' : 'none';
  document.getElementById('authTitle').textContent = mode === 'register' ? 'تۆمارکردنی هەژمار' : 'چوونەژوورەوە';
  document.getElementById('authSubmit').textContent = mode === 'register' ? 'تۆمارکردن' : 'چوونەژوورەوە';
  document.getElementById('authSwitch').innerHTML = mode === 'register'
    ? 'هەژمارت هەیە؟ <button type="button" id="toLogin">چوونەژوورەوە</button>'
    : 'هەژمارت نییە؟ <button type="button" id="toRegister">تۆمارکردن</button>';
  const toggleBtn = document.getElementById(mode === 'register' ? 'toLogin' : 'toRegister');
  toggleBtn.addEventListener('click', () => openAuthModal(mode === 'register' ? 'login' : 'register'));
  authBackdrop.classList.add('open');
}
document.getElementById('loginBtn').addEventListener('click', () => openAuthModal('login'));
document.getElementById('authClose').addEventListener('click', () => authBackdrop.classList.remove('open'));
authBackdrop.addEventListener('click', e => { if (e.target === authBackdrop) authBackdrop.classList.remove('open'); });

authForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('a-email').value.trim();
  const password = document.getElementById('a-password').value;
  const name = document.getElementById('a-name').value.trim();
  const path = authMode === 'register' ? 'register' : 'login';
  const body = authMode === 'register' ? { name, email, password, role: 'buyer' } : { email, password };
  const res = await fetch(`${API}/auth/${path}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) {
    authMsg.textContent = data.error || 'هەڵەیەک ڕوویدا';
    authMsg.className = 'field-full form-msg show err';
    return;
  }
  token = data.token; currentUser = data.user;
  localStorage.setItem('token', token); localStorage.setItem('user', JSON.stringify(currentUser));
  authForm.reset();
  authBackdrop.classList.remove('open');
  updateUserUI();
  render();
});

// ---- Role toggle ----
document.getElementById('rolepick').addEventListener('click', async (e) => {
  const btn = e.target.closest('button[data-role]');
  if (!btn || !currentUser) return;
  const res = await fetch(`${API}/auth/role`, {
    method: 'PATCH', headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({ role: btn.dataset.role }),
  });
  const data = await res.json();
  if (res.ok) {
    token = data.token; currentUser = data.user;
    localStorage.setItem('token', token); localStorage.setItem('user', JSON.stringify(currentUser));
    updateUserUI();
  }
});

// ---- Init ----
updateUserUI();
initMap();
fetchListings();
