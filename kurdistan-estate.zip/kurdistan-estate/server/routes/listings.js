const express = require('express');
const { db, CITY_COORDS } = require('../db');
const { requireAuth, optionalAuth } = require('../middleware/auth');

const router = express.Router();

router.get('/', (req, res) => {
  const { city, type, q } = req.query;
  let sql = 'SELECT * FROM listings WHERE 1=1';
  const params = [];
  if (city) { sql += ' AND city = ?'; params.push(city); }
  if (type) { sql += ' AND type = ?'; params.push(type); }
  if (q) {
    sql += ' AND (title LIKE ? OR area LIKE ? OR city LIKE ?)';
    const like = `%${q}%`;
    params.push(like, like, like);
  }
  sql += ' ORDER BY created_at DESC';
  const rows = db.prepare(sql).all(...params);
  res.json({ listings: rows });
});

router.get('/cities', (req, res) => {
  const rows = db.prepare('SELECT city, COUNT(*) AS count FROM listings GROUP BY city').all();
  res.json({ cities: rows, coords: CITY_COORDS });
});

router.post('/', requireAuth, (req, res) => {
  const { title, city, area, type, price, size, beds } = req.body || {};
  if (!title || !city || !area || !type || !price || !size) {
    return res.status(400).json({ error: 'هەموو خانەکان پێویستن' });
  }
  const coords = CITY_COORDS[city] || {};
  const info = db.prepare(`
    INSERT INTO listings (title, city, area, type, price, size, beds, baths, lat, lng, owner_id, owner_name, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?)
  `).run(
    title.trim(), city, area.trim(), type, price.trim(), size.trim(),
    Number(beds) || 0, coords.lat ?? null, coords.lng ?? null,
    req.user.id, req.user.name, Date.now()
  );
  const row = db.prepare('SELECT * FROM listings WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ listing: row });
});

router.delete('/:id', requireAuth, (req, res) => {
  const row = db.prepare('SELECT * FROM listings WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'ئەندام نەدۆزرایەوە' });
  if (row.owner_id !== req.user.id) {
    return res.status(403).json({ error: 'تەنها خاوەنی ئەندام دەتوانێت بیسڕێتەوە' });
  }
  db.prepare('DELETE FROM listings WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
