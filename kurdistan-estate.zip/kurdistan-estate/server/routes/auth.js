const express = require('express');
const bcrypt = require('bcryptjs');
const { db } = require('../db');
const { signToken, requireAuth } = require('../middleware/auth');

const router = express.Router();

router.post('/register', (req, res) => {
  const { name, email, password, role } = req.body || {};
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'ناو، ئیمەیل و وشەی نهێنی پێویستن' });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: 'وشەی نهێنی دەبێت لانی کەم ٦ پیت بێت' });
  }
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase());
  if (existing) {
    return res.status(409).json({ error: 'ئەم ئیمەیلە پێشتر تۆمارکراوە' });
  }

  const hash = bcrypt.hashSync(password, 10);
  const finalRole = role === 'seller' ? 'seller' : 'buyer';
  const info = db.prepare(`
    INSERT INTO users (name, email, password_hash, role, created_at)
    VALUES (?, ?, ?, ?, ?)
  `).run(name.trim(), email.toLowerCase().trim(), hash, finalRole, Date.now());

  const user = { id: info.lastInsertRowid, name: name.trim(), email: email.toLowerCase().trim(), role: finalRole };
  res.status(201).json({ token: signToken(user), user });
});

router.post('/login', (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: 'ئیمەیل و وشەی نهێنی پێویستن' });
  }
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase().trim());
  if (!row || !bcrypt.compareSync(password, row.password_hash)) {
    return res.status(401).json({ error: 'ئیمەیل یان وشەی نهێنی هەڵەیە' });
  }
  const user = { id: row.id, name: row.name, email: row.email, role: row.role };
  res.json({ token: signToken(user), user });
});

router.get('/me', requireAuth, (req, res) => {
  const row = db.prepare('SELECT id, name, email, role FROM users WHERE id = ?').get(req.user.id);
  if (!row) return res.status(404).json({ error: 'بەکارهێنەر نەدۆزرایەوە' });
  res.json({ user: row });
});

router.patch('/role', requireAuth, (req, res) => {
  const { role } = req.body || {};
  if (!['buyer', 'seller'].includes(role)) {
    return res.status(400).json({ error: 'ڕۆڵی نادروست' });
  }
  db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, req.user.id);
  const row = db.prepare('SELECT id, name, email, role FROM users WHERE id = ?').get(req.user.id);
  res.json({ token: signToken(row), user: row });
});

module.exports = router;
