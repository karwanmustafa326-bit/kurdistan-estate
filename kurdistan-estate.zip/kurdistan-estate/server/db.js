const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'data.sqlite'));
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'buyer',
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS listings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    city TEXT NOT NULL,
    area TEXT NOT NULL,
    type TEXT NOT NULL,
    price TEXT NOT NULL,
    size TEXT NOT NULL,
    beds INTEGER DEFAULT 0,
    baths INTEGER DEFAULT 0,
    lat REAL,
    lng REAL,
    owner_id INTEGER,
    owner_name TEXT,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (owner_id) REFERENCES users(id)
  );
`);

// City coordinates used for map pins and to auto-fill lat/lng on new listings.
const CITY_COORDS = {
  'هەولێر': { lat: 36.1911, lng: 44.0093 },
  'سلێمانی': { lat: 35.5650, lng: 45.4329 },
  'دهۆک': { lat: 36.8642, lng: 42.9990 },
  'کەرکوک': { lat: 35.4681, lng: 44.3922 },
  'هەڵەبجە': { lat: 35.1811, lng: 45.9861 },
  'زاخۆ': { lat: 37.1444, lng: 42.6867 },
};

function seedIfEmpty() {
  const count = db.prepare('SELECT COUNT(*) AS c FROM listings').get().c;
  if (count > 0) return;

  const seed = [
    { title: 'خانووی نوێ لەگەڵ باخچە', city: 'هەولێر', area: 'ئانکاوا', type: 'خانوو', price: '185,000$', size: '320 م²', beds: 4, baths: 3 },
    { title: 'ئاپارتمانی مۆدێرن — نزیک سیتی سێنتەر', city: 'هەولێر', area: 'سیتی سێنتەر', type: 'ئاپارتمان', price: '64,000$', size: '140 م²', beds: 2, baths: 2 },
    { title: 'زەوی بازرگانی لەسەر شەقامی سەرەکی', city: 'سلێمانی', area: 'شەقامی سالم', type: 'زەوی', price: '250,000$', size: '800 م²', beds: 0, baths: 0 },
    { title: 'خانووی دووقاتی گەورە', city: 'دهۆک', area: 'ماسیکی', type: 'خانوو', price: '210,000$', size: '400 م²', beds: 5, baths: 4 },
    { title: 'دوکانی بازرگانی — دووکەلەکە', city: 'سلێمانی', area: 'بازاڕی سەرەکی', type: 'دوکان', price: '1,200$/مانگ', size: '90 م²', beds: 0, baths: 1 },
    { title: 'ئاپارتمانی خانوادەیی', city: 'کەرکوک', area: 'شۆڕجە', type: 'ئاپارتمان', price: '48,000$', size: '115 م²', beds: 2, baths: 1 },
    { title: 'زەوی کشتوکاڵی فراوان', city: 'هەڵەبجە', area: 'دەرەتوو', type: 'زەوی', price: '95,000$', size: '5,000 م²', beds: 0, baths: 0 },
    { title: 'ڤیلای لوکس لەگەڵ حەوزی مەلەوانی', city: 'هەولێر', area: 'دریم سیتی', type: 'خانوو', price: '420,000$', size: '650 م²', beds: 6, baths: 5 },
    { title: 'دوکانی بچووک بۆ کاسبی', city: 'زاخۆ', area: 'ناوەڕاست', type: 'دوکان', price: '350$/مانگ', size: '45 م²', beds: 0, baths: 1 },
  ];

  const insert = db.prepare(`
    INSERT INTO listings (title, city, area, type, price, size, beds, baths, lat, lng, owner_id, owner_name, created_at)
    VALUES (@title, @city, @area, @type, @price, @size, @beds, @baths, @lat, @lng, NULL, NULL, @created_at)
  `);

  const now = Date.now();
  const tx = db.transaction((rows) => {
    rows.forEach((r, i) => {
      const coords = CITY_COORDS[r.city] || {};
      insert.run({ ...r, lat: coords.lat ?? null, lng: coords.lng ?? null, created_at: now - i * 1000 });
    });
  });
  tx(seed);
}

seedIfEmpty();

module.exports = { db, CITY_COORDS };
